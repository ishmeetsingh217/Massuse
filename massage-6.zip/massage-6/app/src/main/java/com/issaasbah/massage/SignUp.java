package com.issaasbah.massage;

import android.content.Intent;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class SignUp extends AppCompatActivity {


    Button login, signUpButton;
    TextInputLayout displayEmail, displayName,displayPassword, displayConfirmPassword;
    TextInputEditText displayEmailTxt, displayNameTxt, displayPasswordTxt, displayConfrimPassTxt;

    private InputValidation inputValidation;
    private DbHelper dbHelper;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        login = findViewById(R.id.button);
        signUpButton = findViewById(R.id.button3);

        displayEmail = findViewById(R.id.signUpEmail);
        displayName = findViewById(R.id.signUpName);
        displayPassword = findViewById(R.id.signUpPassword);
        displayConfirmPassword = findViewById(R.id.signUpConfirmPass);

        displayEmailTxt = findViewById(R.id.emailSignupInputTxt);
        displayNameTxt = findViewById(R.id.nameSignupInputTxt);
        displayPasswordTxt = findViewById(R.id.passSignupInputTxt);
        displayConfrimPassTxt = findViewById(R.id.confrimPassSignUpTxt);

        dbHelper = new DbHelper(SignUp.this);
        inputValidation = new InputValidation(SignUp.this);
        user = new User();


    }


    public void moveLogin(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


    public void signUpUser(View view) {

        postDataToSQLite();

    }

    private void postDataToSQLite() {

        if (!inputValidation.isInputTextFilled(displayNameTxt, displayName)) {
            Toast.makeText(SignUp.this, "Error, empty name field" , Toast.LENGTH_LONG).show();
            return;
        }

        if (!inputValidation.isInputTextFilled(displayEmailTxt, displayEmail)) {
            Toast.makeText(SignUp.this, "Error, empty email field" , Toast.LENGTH_LONG).show();

            return;
        }

        if (!inputValidation.isInputTextEmail(displayEmailTxt, displayEmail)) {
            Toast.makeText(SignUp.this, "Error, invalid email address" , Toast.LENGTH_LONG).show();

            return;
        }

        if (!inputValidation.isInputTextFilled(displayPasswordTxt, displayPassword)) {
            Toast.makeText(SignUp.this, "Error, empty password field" , Toast.LENGTH_LONG).show();

            return;
        }

        if (!inputValidation.isInputTextMatches(displayPasswordTxt, displayConfrimPassTxt, displayConfirmPassword)) {
            Toast.makeText(SignUp.this, "Error, password does not match" , Toast.LENGTH_LONG).show();

            return;
        }




        if (!dbHelper.checkUser(displayEmailTxt.getText().toString().trim())) {


            user.setName(displayNameTxt.getText().toString().trim());
            user.setEmail(displayEmailTxt.getText().toString().trim());
            user.setPassword(displayPasswordTxt.getText().toString().trim());

            dbHelper.addUser(user);

            Toast.makeText(SignUp.this, "SignUp Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            emptyInputEditText();
        }

        else {
            Toast.makeText(this, "Unsuccessful", Toast.LENGTH_LONG).show();
        }

    }

    private void emptyInputEditText() {
        displayNameTxt.setText(null);
        displayEmailTxt.setText(null);
        displayPasswordTxt.setText(null);
        displayConfrimPassTxt.setText(null);
    }


}
