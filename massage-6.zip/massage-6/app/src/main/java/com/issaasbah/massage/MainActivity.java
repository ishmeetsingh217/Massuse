package com.issaasbah.massage;

import android.content.Intent;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {


    private TextInputLayout displayEmail, displayPassword;
    private TextInputEditText displayEmailTxt, displayPasswordTxt;


    private InputValidation inputValidation;
    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayEmail = findViewById(R.id.loginEmail);
        displayPassword = findViewById(R.id.loginPassword);

        displayEmailTxt = findViewById(R.id.loginEmailTxt);
        displayPasswordTxt = findViewById(R.id.loginPasswordTxt);


        dbHelper = new DbHelper(this);
        inputValidation = new InputValidation(this);

    }



    public void moveToSignUp(View view) {
        Intent intent = new Intent(this, SignUp.class);
        startActivity(intent);
    }

    public void moveToMassage(View view) {
        if (!inputValidation.isInputTextFilled(displayEmailTxt, displayEmail)) {
            Toast.makeText(MainActivity.this, "Error, empty email field" , Toast.LENGTH_LONG).show();
            return;

        }
        if (!inputValidation.isInputTextEmail(displayEmailTxt, displayEmail)) {
            Toast.makeText(MainActivity.this, "Error, invalid email address" , Toast.LENGTH_LONG).show();

            return;
        }
        if (!inputValidation.isInputTextFilled(displayPasswordTxt, displayPassword)) {
            Toast.makeText(MainActivity.this, "Error, empty password field" , Toast.LENGTH_LONG).show();

            return;
        }

        if (dbHelper.checkUser(displayEmailTxt.getText().toString().trim(),
                displayPasswordTxt.getText().toString().trim())) {

            Intent intent = new Intent(this, Massage.class);
            emptyInputEditText();
            startActivity(intent);



        } else {
            Toast.makeText(this, "Error, invalid email address or password", Toast.LENGTH_LONG).show();
        }

    }


    private void emptyInputEditText() {
        displayEmailTxt.setText(null);
        displayPasswordTxt.setText(null);
    }



}
