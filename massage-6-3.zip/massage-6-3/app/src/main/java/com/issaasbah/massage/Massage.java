package com.issaasbah.massage;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Massage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_massage);


    }

    public void logoutUser(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


    public void moveToSwedish(View view) {

        Intent intent = new Intent(this, SwedishMassage.class);
        startActivity(intent);

    }

    public void moveToDeep(View view) {
        Intent intent = new Intent(this, DeepTissueMassage.class);
        startActivity(intent);
    }

    public void moveToPrenatal(View view) {
        Intent intent = new Intent(this, PrenatalMassage.class);
        startActivity(intent);
    }

    public void moveToCouples(View view) {
        Intent intent = new Intent(this, CouplesMassage.class);
        startActivity(intent);
    }


    public void moveToSports(View view) {

        Intent intent = new Intent(this, Sports.class);
        startActivity(intent);
    }

    public void moveToSmo(View view ){

        Intent intent = new Intent(this, SmootheAtWork.class);
        startActivity(intent);
    }


}
